# Changelog

## v2.5
- Declared stable
- Added Worker Veto Rights
- Added quantum/BCI protocol
