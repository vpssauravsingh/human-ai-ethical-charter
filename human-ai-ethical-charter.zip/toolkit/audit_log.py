# Basic audit log schema (starter)
import json
from datetime import datetime

def log_event(event_type, user, description):
    log = {
        "timestamp": datetime.utcnow().isoformat(),
        "event_type": event_type,
        "user": user,
        "description": description
    }
    with open("audit_log.json", "a") as f:
        f.write(json.dumps(log) + "\n")
