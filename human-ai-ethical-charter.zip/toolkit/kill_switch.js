// Basic kill switch logic
let systemActive = true;
function triggerKillSwitch() {
  if (confirm("Deactivate AI system?")) {
    systemActive = false;
    alert("System disabled.");
  }
}
